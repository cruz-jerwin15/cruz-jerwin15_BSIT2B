1. npm init -y
2. npm install express mysql2 cors
3. npm install --save-dev nodemon
4. Create js file in the root named database.js
5. create js file in the root named server.js
6. Create 3 folders in the root: routes, models,controllers